// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import CompanyProvider from './components/CompanyContext'; // Import the CompanyProvider
import Dashboard from './components/user/Dashboard'; // Your Dashboard component
import CompanyManagement from './components/admin/CompanyManagement'; // Company Management component
import CalendarView from './components/user/CalendarView'; // Calendar View component
import SelectionPage from './components/SelectionPge'; // Admin/User selection page

const App = () => {
  return (
    <CompanyProvider>
      <Router>
        <Routes>
          {/* Default selection page */}
          <Route path="/" element={<SelectionPage />} />

          {/* Admin page */}
          <Route path="/admin" element={<CompanyManagement />} />

          {/* User pages */}
          <Route
            path="/user"
            element={
              <>
                <Dashboard />
                <CalendarView />
              </>
            }
          />

          {/* Retain existing components (render on the main app, if needed) */}
          <Route
            path="/all"
            element={
              <>
                <CompanyManagement />
                <Dashboard />
                <CalendarView />
              </>
            }
          />
        </Routes>
      </Router>
    </CompanyProvider>
  );
};

export default App;
